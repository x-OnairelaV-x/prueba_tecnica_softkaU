import view from "../views/post.html";

const getpost = async () => {
    const response = await fetch('https://jsonplaceholder.typicode.com/posts');
        return await response.json();
} 

export default async() => {
    const divElement = document.createElement("div");
        divElement.innerHTML = view;

        const postelements = divElement.querySelector('#post')
        const post = await getpost();

       post.forEach(post => {
           postelements.innerHTML +=`
           <li class="list-group-item">
            <h5>${post.title}</h5>
            <p1>${post.body}</p1>
           </li>
           `
       })
        return divElement;
    };