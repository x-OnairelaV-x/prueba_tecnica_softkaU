import home from './home.controllers'
import post from "./post.controller"
import notfound from './404.controller'
const pages = {
    home: home,
    post: post,
    notfound: notfound,
}
export {pages};