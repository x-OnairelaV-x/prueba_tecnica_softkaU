const Post = async (url ,data) =>{
    const response =  fetch(url, {
         method: 'POST',
         headers: {
             'Content-Type': 'application/json',
         },
         body: JSON.stringify(data),
         })
         .then((response) => response.json())
         //Then with the data from the response in JSON...
         .then((data) => {
             console.log('Success:', data);
             return data ;
         
         })
         //Then with the error genereted...
         .catch((error) => {
             console.error('Error:', error);
             return error;
 
         });
     return response;
 }

 const Get = async (url) =>{
    const response = await fetch(url)
    .then((response) => response.json())
    //Then with the data from the response in JSON...
    .then((data) => {
        console.log('Success:', data);
        return data ;
    
    })
    //Then with the error genereted...
    .catch((error) => {
        console.error('Error:', error);
        return error;

    });
     return response;
 }

 const httpClient = {
    post: Post,
    get:Get
 }
 export {httpClient};